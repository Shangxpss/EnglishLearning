import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import path from "path";
// https://vite.dev/config/
export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "src"),
    },
  },
  server: {
    proxy: {
      "/api": {
        target: "http://localhost:8007",
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, ""),
      },
      // CopilotKit runtime (Bun) — proxies /copilotkit requests to the
      // agent-runtime, which in turn forwards them to the Python LangGraph
      // agent mounted at /copilotkit-agent on the English Learning backend.
      "/copilotkit": {
        target: "http://localhost:4000",
        changeOrigin: true,
      },
    },
  },
});
